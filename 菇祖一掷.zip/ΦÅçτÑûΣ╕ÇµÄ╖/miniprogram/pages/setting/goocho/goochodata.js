export default [{
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NTE=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '痴情司',
    author: 'hocc'
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1OTc=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '木纹',
    author: 'hocc'
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDAxODU=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '钢铁是怎样炼成的',
    author: 'hocc'
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3MzQ=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '妮歌',
    author: 'hocc'
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NTg=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '劳斯莱斯',
    author: "hocc",
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NTc=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '化蝶',
    author: "hocc",
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1MjQ=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '忘',
    author: "hocc"
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2OTM=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '光荣之家',
    author: 'hocc'
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3MzM=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '明目张胆',
    author: 'hocc'
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF8yNjUwMTY0NzQ0',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '出走太平洋',
    author: 'hocc'
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NTM=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '我找到了',
    author: 'hocc'
  },
  {
    src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NTQ=',
    poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
    name: '夕阳之歌',
    author: 'hocc'
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1MDM=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '亲爱的黑色',
  author: 'hocc'
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NjA=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '是有种人',
  author: 'hocc'
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NTk=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '我是现在',
  author: 'hocc'
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NTY=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '风雨同路',
  author: "hocc",
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NTU=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '爱无愧',
  author: "hocc",
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2MDU=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '亲爱的玛嘉烈',
  author: "hocc"
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NTI=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '同窗会',
  author: 'hocc'
  },
  {  
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1NTA=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '蔓珠沙华',
  author: 'hocc'
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2MTM=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '不眠皇后',
  author: 'hocc'
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2MTg=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '愿我可以学会放低你',
  author: 'hocc'
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1MzY=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '露丝玛莉',
  author: 'hocc'
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1MTc=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '诗与胡说',
  author: 'hocc'
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2Mjk=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '千千万万个我',
  author: 'hocc'
  },
  {
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2Mzc=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '再见，露丝玛莉',
  author: 'hocc'
  },
{
src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2MzU=',
poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
name: '眼泪教会我的事',
author: "hocc",
},
{
src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2MzY=',
poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
name: '喜欢喜欢你',
author: "hocc",
},
{
src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2NTE=',
poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
name: '夜半敲门',
author: "hocc"
},
{
src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2Mzg=',
poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
name: '如无意外',
author: 'hocc'
},
{
src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2NDc=',
poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
name: '光明会',
author: 'hocc'
},
{
src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2NDk=',
poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
name: '红屋顶',
author: 'hocc'
},
{
src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2ODA=',
poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
name: '出生入死',
author: 'hocc'
},
{
src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2ODE=',
poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
name: '韵律泳',
author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2OTI=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '你是八十年代',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDAwMzE=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '旧约',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDAwNTk=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '风见志郎',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3MTY=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '未来',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3MTc=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '沙',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3MTg=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '圆满',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA2NDg=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '花见',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1MjI=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '歌之女',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDAwOTM=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '兄弟',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3MzU=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '极夜后',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3Mzc=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '萨拉热窝的罗密欧与朱丽叶',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3MzY=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '彼此',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3NDA=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '无名',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3Mzk=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '疯子',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3NjQ=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '菇菇歌',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3NjM=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: 'Medley-将冰山劈开-妖女',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3NjI=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '小情歌',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3NzI=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '月亮代表我的心',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3NzE=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '坏女孩',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3NzA=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '情深说话未曾讲',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3OTU=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '不再让你孤单',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA1Mjg=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: 'All is fair',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8xMDAwMDA3OTc=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '美丽新香港',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NDQx',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '海阔天空',
  author: '菇祖..等'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTA3',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '代你白头',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTA4',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '叹息桥',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTA5',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '天使蓝',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTEw',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '似是故人来',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTEx',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '第三身',
  author: '麦浚龙x菇'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTEy',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '青山黛玛',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTEz',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: 'each other',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTE0',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '爱',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTE1',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '抛砖引玉',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTE2',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '无赖',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTE3',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '同不同',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTE4',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '与别不同',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTE5',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '神经痛',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTIw',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '迷你与我',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTIx',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '水花四溅',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTIy',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '吉他教室',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTIz',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: 'acoustic angel',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTI0',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '劲爱你',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTI2',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: 'Shampoo',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTI3',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '独乐乐',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTI4',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '爱情花',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTI5',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '一家之主',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI2NzU4MjA2MF8yMjQ3NDg0NTMw',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '我会选择C',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMjQ=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '韵律泳（memento）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMjU=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '劳斯莱斯（memento）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMjM=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '不眠皇后（memento）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMjY=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '痴情司（memento）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMjc=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '光明会（memento）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMjg=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '你是八十年代（memento）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMzA=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '睡王子（memento）',
  author: '麦浚龙x菇'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMzE=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '满地可（memento）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMzI=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '爱没有不可（memento）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMzM=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '忘（麦花臣）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMzQ=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '有一种裂痕（Reimagine） ',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMzU=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '爱德蒙多（Reimagine）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMzY=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '美空云雀（Reimagine）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMzc=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '幽默感（Reimagine）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwMzg=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '大红袍（supergoo）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwNDA=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '冰心（supergoo）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwNDE=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '少年维特（supergoo）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwNDI=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '以身犯险（supergoo）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwNDM=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '绝对（supergoo）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwNDQ=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '查理淑仪（supergoo）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwNDU=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '万花筒（supergoo）',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwNDc=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '无脸人',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwNDg=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '汽水樽里的咖啡',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF81MDI2ODEwNDk=',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '禁色',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF8yNjUwMTY0NzM4',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '芳华绝代',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzI1NzIxNDAxNF8yNjUwMTY0NzM3',
  poster: 'http://p2.music.126.net/IFQMEEPzQ9TVJmg-dnMdmA==/19229358858247783.jpg',
  name: '蚂蚁',
  author: 'hocc'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzU2NjY0MDg3OV8yMjQ3NDgzNzAz',
  poster: 'https://pic4.zhimg.com/80/v2-caf325d98d06f4df794703ddd1d23e87_720w.jpg',
  name: '石头记',
  author: '达明一派'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzIyNjYyNDEzMl8yMjQ3NDg4MTAw',
  poster: 'https://pic4.zhimg.com/80/v2-caf325d98d06f4df794703ddd1d23e87_720w.jpg',
  name: '四季歌',
  author: '达明一派'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzUzMDA2NTE4MV8yMjQ3NDgzNzIy',
  poster: 'https://pic4.zhimg.com/80/v2-caf325d98d06f4df794703ddd1d23e87_720w.jpg',
  name: '十个救火的少年',
  author: '达明一派'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzUzMDA2NTE4MV8yMjQ3NDg0MDk0',
  poster: 'https://pic4.zhimg.com/80/v2-caf325d98d06f4df794703ddd1d23e87_720w.jpg',
  name: '今天应该很高兴',
  author: '达明一派'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzUzMDA2NTE4MV8yMjQ3NDg0MDk1',
  poster: 'https://pic4.zhimg.com/80/v2-caf325d98d06f4df794703ddd1d23e87_720w.jpg',
  name: '1+4=14',
  author: '达明一派'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzUzMDA2NTE4MV8yMjQ3NDgzNzQ3',
  poster: 'https://pic4.zhimg.com/80/v2-caf325d98d06f4df794703ddd1d23e87_720w.jpg',
  name: '十个放火的少年',
  author: '达明一派'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzUzMDA2NTE4MV8yMjQ3NDgzNzUy',
  poster: 'https://pic4.zhimg.com/80/v2-caf325d98d06f4df794703ddd1d23e87_720w.jpg',
  name: '天问',
  author: '达明一派'
},
{
  src: 'https://res.wx.qq.com/voice/getvoice?mediaid=MzUzMDA2NTE4MV8yMjQ3NDg0MDk2',
  poster: 'https://pic4.zhimg.com/80/v2-caf325d98d06f4df794703ddd1d23e87_720w.jpg',
  name: '天国近了（你们应当游戏）',
  author: '达明一派'
}
]