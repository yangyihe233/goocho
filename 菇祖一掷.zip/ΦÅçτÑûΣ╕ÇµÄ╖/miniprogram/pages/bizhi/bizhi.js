//index.js
//获取应用实例

var Bmob = require('../../utils/bmob.js');
var app = getApp();
Page({
  data: {
    animationData: {},
    cardInfoList: [
      {
        p_type: 'b_fengjing',
        cardUrl: 'https://mmbiz.qpic.cn/mmbiz_jpg/Sic15gMo8kVb3uMjzebdImibjAN9xAhSmDK1iaKLWMV75OLmXUWWcacDjFOhhYT21yRbST5WJ6AEraicRA5EMBW30Q/0?wx_fmt=jpeg&quot=',
        cardInfo: {
          cardTitle: '五月，你好',
          cardInfoMes: ['奋勇呀', '然后休息呀', '完成你伟大的人生'],
        }
      },
      {
      p_type: 'b_dongman',
      cardUrl: 'https://mmbiz.qpic.cn/mmbiz_jpg/Sic15gMo8kVb3uMjzebdImibjAN9xAhSmDAyttDLArb65IXcPD3TYib9xiaFGlXonibAa4y2njDto41L7Q7av4Ucd6Q/0?wx_fmt=jpeg&quot=',
      cardInfo: {
        cardTitle: '宜浪漫',
        cardInfoMes: ['细雨扑面', '如果在快乐中', '快乐增倍'],
      
      }
    },
    {
        p_type: 'b_renwu',
        cardUrl: 'https://mmbiz.qpic.cn/mmbiz_jpg/Sic15gMo8kVb3uMjzebdImibjAN9xAhSmDiaxFqy2QXsbTudFxsfN1JkMZiccPDCTJuVAS1GRvouQSdlraaqFOEvtQ/0?wx_fmt=jpeg&quot=',
        cardInfo: {
          cardTitle: '忌遗忘',
          cardInfoMes: ['从别后', '忆相逢', '几回魂梦与君同'],
       
      }
    }
  ]
  },
  //事件处理函数
  slidethis: function (e) {
    console.log(e);
    var animation = wx.createAnimation({
      duration: 300,
      timingFunction: 'cubic-bezier(.8,.2,.1,0.8)',
    });
    var self = this;
    this.animation = animation;
    this.animation.translateY(-420).rotate(-5).translateX(0).step();
    this.animation.translateY(62).translateX(25).rotate(0).step();
    this.setData({
      animationData: this.animation.export()
    });
    setTimeout(function () {
      var cardInfoList = self.data.cardInfoList;
      var slidethis = self.data.cardInfoList.shift();
      self.data.cardInfoList.push(slidethis);
      self.setData({
        cardInfoList: self.data.cardInfoList,
        animationData: {}
      });
    }, 350);
  },
  buythis: function (e) {
    console.log(e);
    app.buyDetail = this.data.cardInfoList[e.target.id];
   // wx.navigateTo({
    //  url: '../log/log'
  //  });
  },
  onShareAppMessage:function(options){

  }
})
