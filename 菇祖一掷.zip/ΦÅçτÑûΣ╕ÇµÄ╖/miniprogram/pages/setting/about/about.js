//about.js
Page({
  data:{
    donation : '../../../res/img/donation.png'
  },
  onLoad : function(){
      
  }
})