var app = getApp()
Page({
  data:{
    autodown : true,
    autoplay : true,

    toastHidden : true,
    modalHidden : true
  },

  toastChange   : function(e){
    this.setData({toastHidden:true});
  }
  ,modalChange   : function(e){
    this.setData({ modalHidden : true});

    if(e.type == "confirm"){
        //执行清除操作 
        wx.clearStorage()
        this.setData({toastHidden:false});
     }
     
  } 
  ,clearStorageHandler : function(e){
      this.setData({ modalHidden : false});
  }
})