import data from "../../setting/goocho/goochodata.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    playStatus: true,
    audioIndex: 0,
    progress: 0,
    duration: 0,
    audioList: [],
    showList: true,
    songTextList:[]
    },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

 //文稿内容
 /*
 var str = '[00:00.00]痴情司\n[00:02.60]作曲：何秉舜 @goomusic\n[00:06.60]填词：黄伟文\n[00:09.54]歌手：何韵诗\n[00:12.53]\n[00:22.79]\n[00:24.38]梦还没有完 大寒尚有蝉\n[00:29.78]夜来冒风雪 叫唤着雨点\n[00:35.35]梦还没有完 断垣望归燕\n[00:40.72]有人情痴得 不怕天地变\n[00:47.22]\n[00:56.16]梦还没有完 泪流尚觉甜\n[01:01.47]别离亦不怕 约誓在耳边\n[01:06.97]梦还没有完 命途若不变\n[01:12.41]你还能偏执 拖到几丈远\n[01:19.53]\n[01:21.38]其实你我这美梦 气数早已尽\n[01:27.78]重来也是无用\n[01:32.53]情愿百世都赞颂 最美的落红\n[01:38.91]敢舍弃才是勇\n[01:44.78]\n[01:45.53]梦还没有完 恨还没有填\n[01:51.10]牵挂像笔债 再聚又再添\n[01:56.59]梦还没有完 越还越亏欠\n[02:02.20]叹红楼金叉 醒觉不复见\n[02:09.34]\n[02:23.72]\n[02:27.16]梦太好 别相信\n[02:34.47]其实你我这美梦 气数早已尽\n[02:40.91]重来也是无用\n[02:45.66]情愿百世都赞颂 最美的落红\n[02:52.33]曾为君栽种\n[02:58.59]\n[02:59.42]其实你我这美梦 气数早已尽\n[03:05.66]缠绵也是无用\n[03:10.53]情愿百世都赞颂 最爱的面容\n[03:17.09]因爱而目送\n[03:23.65]梦还没有完 愿还没有圆\n[03:29.09]漫长地心算 快乐却太短\n[03:35.09]\n[03:40.10]有谁情痴得 不怕天地变\n[03:47.21]\n[03:55.34]一片白茫茫里面\n[04:00.96]\n[04:06.34]让情痴一洗恨怨\n[04:12.09]\n[04:20.15]今世若无权惦念\n[04:25.78]\n[04:31.46]迟一点 天上见\n[04:36.90]',
    this.setData({
      songTextList:str.split(',').map(r=>r.trim())
    })
    console.log(this.data.songTextList)
*/

    this.setData({
      audioList: data
    })
    this.playMusic();
  },

  playMusic: function() {
    let audio = this.data.audioList[this.data.audioIndex];
    let manager = wx.getBackgroundAudioManager();
    manager.title = audio.name || "音频标题";
    manager.epname = audio.epname || "歌手";
    manager.singer = audio.author || "歌手";
    manager.lrc = audio.lrc || "歌词";
    manager.coverImgUrl = audio.poster;
    // 设置了 src 之后会自动播放
    manager.src = audio.src;
    manager.currentTime = this.data.audioIndex;
    let that = this;
    manager.onPlay(function() {
      console.log("======onPlay======");
      that.setData({
        playStatus: true
      })
      that.countTimeDown(that, manager);
    });
    manager.onPause(function() {
      that.setData({
        playStatus: false
      })
      console.log("======onPause======");
    });
    manager.onEnded(function() {
      console.log("======onEnded======");
      that.setData({
        playStatus: false
      })
      setTimeout(function() {
        that.nextMusic();
      }, 1500);
    });
  },

  //循环计时
  countTimeDown: function(that, manager, cancel) {
    if (that.data.playStatus) {
      setTimeout(function() {
        if (that.data.playStatus) {
          // console.log("duration: " + manager.duration);
          // console.log(manager.currentTime);
          that.setData({
            progress: Math.ceil(manager.currentTime),
            progressText: that.formatTime(Math.ceil(manager.currentTime)),
            duration: Math.ceil(manager.duration),
            durationText: that.formatTime(Math.ceil(manager.duration))
          })
          that.countTimeDown(that, manager);
        }
      }, 1000)
    }
  },

  //拖动事件
  sliderChange: function(e) {
    let manager = wx.getBackgroundAudioManager();
    manager.pause();
    manager.seek(e.detail.value);
    this.setData({
      progressText: this.formatTime(e.detail.value)
    })
    setTimeout(function() {
      manager.play();
    }, 1000);
  },

  //列表点击事件
  listClick: function(e) {
    let pos = e.currentTarget.dataset.pos;
    if (pos != this.data.audioIndex) {
      this.setData({
        audioIndex: pos,
        showList: false
      })
      this.playMusic();
    } else {
      this.setData({
        showList: false
      })
    }
  },

  //上一首
  lastMusic: function() {
    let audioIndex = this.data.audioIndex > 0 ? this.data.audioIndex - 1 : this.data.audioList.length - 1;
    this.setData({
      audioIndex: audioIndex,
      playStatus: false,
      progress: 0,
      progressText: "00:00",
      durationText: "00:00"
    })
    setTimeout(function() {
      this.playMusic();
    }.bind(this), 1000);
  },

  //播放按钮
  playOrpause: function() {
    let manager = wx.getBackgroundAudioManager();
    if (this.data.playStatus) {
      manager.pause();
    } else {
      manager.play();
    }
  },

  //下一首
  nextMusic: function() {
    let audioIndex = this.data.audioIndex < this.data.audioList.length - 1 ? this.data.audioIndex + 1 : 0;
    this.setData({
      audioIndex: audioIndex,
      playStatus: false,
      progress: 0,
      progressText: "00:00",
      durationText: "00:00"
    })
    setTimeout(function() {
      this.playMusic();
    }.bind(this), 1000);
  },

  //界面切换
  pageChange: function() {
    this.setData({
      showList: true
    })
  },

   //单曲循环
   songxunhuan: function() {
    this.setData({
      slider_value: 0,
      current_process: '00:00',
    })
    
  },

  //格式化时长
  formatTime: function(s) {
    let t = '';
    s = Math.floor(s);
    if (s > -1) {
      let min = Math.floor(s / 60) % 60;
      let sec = s % 60;
      if (min < 10) {
        t += "0";
      }
      t += min + ":";
      if (sec < 10) {
        t += "0";
      }
      t += sec;
    }
    return t;
  
  },

 

   
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

 // 获取scroll-view的节点信息
 //创建节点选择器
 var query = wx.createSelectorQuery();
 query.select('.container').boundingClientRect()
 query.select('.list').boundingClientRect()
 query.exec((res) => {
 var containerHeight = res[0].height;
 var listHeight = res[1].height;
  
 // 滚动条的高度增加
 var interval = setInterval(() => {
 if (this.data.scrollTop < listHeight - containerHeight) {
  this.setData({
  scrollTop: this.data.scrollTop + 10
  })
 } else {
  // clearInterval(interval);
  this.setData({
  scrollTop: 0
  })
 }
 }, 1000)
 })
  
 },
 scroll: function () {
 // 获取scroll-view的节点信息
 //创建节点选择器
 var query = wx.createSelectorQuery();
 query.select('.list').boundingClientRect()
 query.exec((res) => {
 this.setData({
 scrollTop: -(res[0].top)
 })
 // console.log(res);
 })

  },

  /**
     * 搜索歌曲模块
     */
  Search: function(e) {
      var content = e.detail.value.replace(/\s+/g, '');
      // console.log(content);
      var that = this;
      that.setData({
          SearchContent: content,
      });
  },
  SearchSubmit: function (e) {
      // console.warn(this.data.SearchContent);

      var that = this;
      that.setData({
        songTextList: null,
      });

      var urlsongTextList =  this.data.SearchContent;
      var token = app.globalData.token;
      var params = {};


      //@todo 搜索歌曲网络请求API数据
      request.requestPostApi(urlsongTextList, token, params, this, this.successSearch, this.failSearch);
  },
  successSearch: function (res, selfObj) {
      var that = this;
      // console.warn(res.data.content);
      var list = res.data.content;
      for (let i = 0; i < list.length; ++i) {
          list[i].createTime = util.customFormatTime(list[i].createTime, 'Y.M.D');
      }
      if (res.data.content != "") {
          that.setData({
              songTextList: res.data.content,
              moreFlag: false,
              pages: res.data.pages,
          });
      } else {
          that.setData({
              songTextList: res.data.content,
              moreFlag: true,
              pages: res.data.pages,
          });
      }
  },
  failSearch: function (res, selfObj) {
      console.error('failSearch', res)
 },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})