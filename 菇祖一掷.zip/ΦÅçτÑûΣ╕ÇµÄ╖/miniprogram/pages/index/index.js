//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    userInfo: wx.getStorageSync(app.globalData.userInfoKey),
    hasUserInfo: app.globalData.hasUserInfo,
    imgUrls: [
      'http://mmbiz.qpic.cn/mmbiz_jpg/Sic15gMo8kVac46ibrL3V551iaQ44MKELvQ4icib8RI19OdTjteu8GeZpBVuvnZp3PZvADFIQq96OP2nXia89B7zqfBA/0?wx_fmt=jpeg&quot=',
      'http://mmbiz.qpic.cn/mmbiz_jpg/Sic15gMo8kVaEwzVtaJQnzBaicfypyicBrnHn3BDy6Ep3tSKTfAjMKoCJknJGib2cuaU3d7KFovmmibtoryQmxy87Sg/0?wx_fmt=jpeg&quot=',
      'http://mmbiz.qpic.cn/mmbiz_jpg/Sic15gMo8kVZ0XOB38SFiaEaCbYDgUpGjlibvleicDghotKOgw13Ee4quGfcnghSs4H2WYNlmia6BpR9RLZ3XWNBZSA/0?wx_fmt=jpeg&quot=',
      'https://mmbiz.qpic.cn/mmbiz_jpg/Sic15gMo8kVaEwzVtaJQnzBaicfypyicBrnxrpvhqx7I4zdUeLd3H3qicHYwSzH7sf671RzDiaiasefGMUzXARRKYfwg/640?wx_fmt=jpeg'
    ],
    indicatorDots: false,
    autoplay: true,
    interval: 5000,
    duration: 800,
    isShowUserPannel:false, //是否显示个人中心面板
  },
  onLoad: function () {
   
  },
/*
  ,showUserPannel: function(){
    let isShow = this.data.isShowUserPannel
    if (!isShow) {
      isShow = true
    } else {
      isShow = false
    }
    this.setData({
      isShowUserPannel: isShow
    })
  }
 */
  onShareAppMessage:function(options){

}
})

